package com.ofss.topic;

import java.util.Properties;

import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.InitialContext;

import com.sun.messaging.jmq.jmsserver.core.Session;

public class PublisherTopic {
	public static void main(String[] args) {
		
		try {
		Properties props=new Properties();
		// The property names will be the same always
		// Step1: obtaining the Initial Context object
		// The property values will be different depends on jms implementor
		props.setProperty("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");
		props.setProperty("java.naming.factory.url.pkgs", "com.sun.enterprise.naming");
		props.setProperty("java.naming.provider.url", "iiop://localhost:3700");// Inter ORB protocol of glassfish server
		InitialContext ctx=new InitialContext(props);
		
		// upto here, the same code
		
		// Step 2:
		// since this method returns Object, we need to typecast it accordingly
		// If you deal with Topic, then you need to typecast this object into TopicConnectionFactory object
		TopicConnectionFactory f=(TopicConnectionFactory)ctx.lookup("jms/cf1");
		
		
		
		
		TopicConnection con=f.createTopicConnection();
		
		con.start();
		
		// Step 3: Create a queue session from this connection
		TopicSession ses=con.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
		
		// Step 4: Get the queue name using JNDI
		Topic t=(Topic)ctx.lookup("jms/Jan2023-Topic");
		
		// Step 5: Create a pubilshere object
		TopicPublisher publisher= ses.createPublisher(t);
		publisher.setTimeToLive(10000); // 10 seconds
		
		System.out.println("Publisher destination is "+publisher.getDestination());
		System.out.println("TTL ...."+publisher.getTimeToLive());
		System.out.println("Topic name "+publisher.getTopic());
        int i=1;
		while(i<10000) {
			// Create the TextMessage now
			TextMessage msg=ses.createTextMessage();
			msg.setText("This is the first msg to the topic="+i);
			publisher.publish(msg);
			System.out.println(msg.getText());
			i++;
		}
		
		publisher.close();
		ses.close();
		con.close();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
}

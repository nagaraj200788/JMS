package com.ofss.topic;


import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import com.ofss.employeesendreceive.Employee;

// This is a listener program, you need to keep this program running
// so that as soon the msg arrives at the queue, this onMessage() method 
// will be triggerd immeidately, so that we can consume the msg from the queue
public class ListenerEmployeeTopic implements MessageListener{

	@Override
	public void onMessage(Message m) {
		//System.out.println("onMessage is trigged, that means a new msg. has arrived");
		if (m instanceof TextMessage)
		{
		//	System.out.println("This is a text msg");
			// If so, let's typecast this into TextMessage type
			TextMessage msg=(TextMessage)m;
			try {
				System.out.println("Message received is "+msg.getText());
				// logic1
				// logic2
				// you can do the data processsing here
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // we need to call getText() method here
		}
		else
		{
			System.out.println("it is not a text message ");
			try {
				Object obj=((ObjectMessage)m).getObject(); // still it is not Employee object
				String className=obj.getClass().getName();
				if (className.contains("Employee"))
				{
					Employee emp=(Employee)obj; // here, we are narrowing down the data type to Employee 
					System.out.println(emp); // toString will be called 
				}
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	
	

}

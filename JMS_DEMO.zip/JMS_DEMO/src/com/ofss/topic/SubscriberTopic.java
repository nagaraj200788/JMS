package com.ofss.topic;

import java.util.Properties;

import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.InitialContext;

import com.sun.messaging.jmq.jmsserver.core.Session;
import java.util.Properties;

import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.InitialContext;

import com.sun.messaging.jmq.jmsserver.core.Session;

public class SubscriberTopic {

	public static void main(String[] args) {
		try {
			Properties props=new Properties();
			// The property names will be the same always
			// Step1: obtaining the Initial Context object
			// The property values will be different depends on jms implementor
			props.setProperty("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");
			props.setProperty("java.naming.factory.url.pkgs", "com.sun.enterprise.naming");
			props.setProperty("java.naming.provider.url", "iiop://localhost:3700");// Inter ORB protocol of glassfish server
			InitialContext ctx=new InitialContext(props);
			
			TopicConnectionFactory f=(TopicConnectionFactory)ctx.lookup("jms/cf1");
			
			
			
			
			TopicConnection con=f.createTopicConnection();
			
			con.start();
			
			// Step 3: Create a topic session from this connection
			TopicSession ses=con.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
			
			// Step 4: Get the topic name using JNDI
			Topic t=(Topic)ctx.lookup("jms/Jan2023-Topic");
			
			
			// Create TopicSubscriper object
			TopicSubscriber receiver= ses.createSubscriber(t);
			
			// Step 6: Create Listener object
			
			ListenerEmployeeTopic listener=new ListenerEmployeeTopic(); // This is user defined class
			
			// Step 7: Register this listener with receier
			
			receiver.setMessageListener(listener);
			System.out.println("Subscriber is ready, waiting for messages.....");
			while (true)
			{
			
			
			}
		
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

	}

}

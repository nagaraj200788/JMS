package com.ofss.singletextmessage;


import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

// This is a listener program, you need to keep this program running
// so that as soon the msg arrives at the queue, this onMessage() method 
// will be triggerd immeidately, so that we can consume the msg from the queue
public class ListenerMessage implements MessageListener{

	@Override
	public void onMessage(Message m) {
		System.out.println("onMessage is trigged, that means a new msg. has arrived");
		if (m instanceof TextMessage)
		{
			// If so, let's typecast this into TextMessage type
			TextMessage msg=(TextMessage)m;
			try {
				System.out.println("Message received is "+msg.getText());
				// you can do the data processsing here
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // we need to call getText() method here
		}
		
	}

	
	

}
